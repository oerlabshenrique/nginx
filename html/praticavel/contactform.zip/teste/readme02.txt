  =======================================================
    Project Name: Praticavel de Bateria Alberto Ramos
    Project URL: https://albertoramos.com.br
    Author: OER Tecnologia
    Author URL: https://oertecnologia.com
  =======================================================
